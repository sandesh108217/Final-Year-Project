from django.contrib import admin
from .models import ImgUpload
# Register your models here.


class ImgUploadAdmin(admin.ModelAdmin):
    list_display = ('imgCaption', 'img', 'date')


admin.site.register(ImgUpload, ImgUploadAdmin)