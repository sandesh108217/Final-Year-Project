from django.db import models


# Create your models here.

class ImgUpload(models.Model):
    imgCaption = models.CharField(max_length=200)
    img = models.ImageField(upload_to='photos')
    date = models.DateTimeField(auto_now=True)
