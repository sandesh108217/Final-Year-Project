from django.shortcuts import render, redirect
from .models import ImgUpload


# Create your views here.


def uploadImages(request):
    images = ImgUpload.objects.all()
    return render(request, "gallery.html", {'images': images})


