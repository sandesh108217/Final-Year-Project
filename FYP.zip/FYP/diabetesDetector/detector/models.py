from django.db import models

# Create your models here.


class detectParameters(models.Model):
    pregnancies = models.IntegerField()
    glucose = models.FloatField()
    BP = models.IntegerField()
    SkinThickness = models.FloatField()
    insulin = models.FloatField()
    BMI = models.FloatField()
    DPFunction = models.FloatField()
    age = models.IntegerField()
    outcome = models.IntegerField()

    def to_dict(self):
        return {
         'pregnancies': self.pregnancies,
         'glucose': self.glucose,
         'BP': self.BP,
         'SkinThickness': self.SkinThickness,
         'insulin': self.insulin,
         'BMI': self.BMI,
         'DPFunction': self.DPFunction,
         'age': self.age,
         'outcome': self.outcome,

        }

