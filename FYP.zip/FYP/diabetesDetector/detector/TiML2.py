import os

import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import confusion_matrix
import pickle


def pre_proc(df):
    df['glucose'].fillna(df['glucose'].mean(), inplace=True)
    df['SkinThickness'].fillna(df['SkinThickness'].mean(), inplace=True)
    df['BP'].fillna(df['BP'].median(), inplace=True)
    df['insulin'].fillna(df['insulin'].mean(), inplace=True)
    df['insulin'].fillna(df['insulin'].mean(), inplace=True)

    return df


def training(df):
    df = pre_proc(df)
    y = df['outcome']
    df.drop("outcome", axis="columns", inplace=True)
    X = df
    dummyRow = pd.DataFrame(np.zeros(len(X.columns)).reshape(1, len(X.columns)), columns=X.columns)
    dummyRow.to_csv("dummyRow.csv", index=False)

    model = KNeighborsClassifier(1)
    X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8, random_state=0)
    model.fit(X, y)

    pkl_filename = 'pickle_model.pkl'
    with open(pkl_filename, 'wb') as file:
        pickle.dump(model, file)

    print(model.score(X, y))
    predictions = model.predict(X_test)
    matrix = confusion_matrix(y_test, predictions)
    print(matrix)


def pred(ob):
    d1 = ob.to_dict()
    df = pd.DataFrame(d1, index=[0])
    df.drop("outcome", axis="columns", inplace=True)
    df = pre_proc(df)
    dummyrow_filename = "./dummyRow.csv"
    dummyrow_filename = os.path.dirname(__file__) + "/" + dummyrow_filename
    df2 = pd.read_csv(dummyrow_filename)
    for c1 in df.columns:
        df2[c1] = df[c1]
    pkl_filename = "pickle_model.pkl"
    pkl_filename = os.path.dirname(__file__) + "/" + pkl_filename
    with open(pkl_filename, 'rb') as file:
        model = pickle.load(file)
    pred = model.predict(df2)
    return pred


if __name__ == "__main__":
    df = pd.read_csv("diabetes.csv")
    training(df)
