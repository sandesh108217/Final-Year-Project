from django.shortcuts import render
from django.http.response import HttpResponse
from rest_framework import viewsets
from detector.models import detectParameters
from detector.myserializer import detectParametersSerializer
from detector.models import detectParameters
from detector import TiML2
from rest_framework.response import Response

# Create your views here.


class detectParametersViewSet(viewsets.ModelViewSet):
    queryset = detectParameters.objects.order_by("-id")
    serializer_class = detectParametersSerializer

    def create(self, request, *args, **kwargs):
        viewsets.ModelViewSet.create(self, request, *args, **kwargs)
        ob = detectParameters.objects.latest("id")
        y = TiML2.pred(ob)
        return Response({"status": "Success", "Diabetic status": y, 'tmp': args})
