from django.contrib import admin
from detector.models import detectParameters

# Register your models here.


admin.site.register(detectParameters)