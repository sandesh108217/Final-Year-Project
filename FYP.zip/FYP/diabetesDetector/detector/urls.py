
from django.contrib import admin
from django.urls import path
from django.urls.conf import include
from django.views.generic.base import RedirectView
from rest_framework import routers
from detector import views


routers = routers.DefaultRouter()
routers.register(r'detector', views.detectParametersViewSet)

urlpatterns = [
    path(r'api/', include(routers.urls)),
    path('', RedirectView.as_view(url="api/")),



]
