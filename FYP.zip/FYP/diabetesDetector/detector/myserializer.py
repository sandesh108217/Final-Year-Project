from detector.models import detectParameters
from rest_framework import serializers


class detectParametersSerializer(serializers.HyperlinkedModelSerializer):
    class Meta:
        model = detectParameters
        fields = "__all__"
