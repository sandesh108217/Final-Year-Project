from django.contrib import admin
from . models import uploadInfo
# Register your models here.


class uploadInfoAdmin(admin.ModelAdmin):
    list_display = ('title', 'info', 'date')


admin.site.register(uploadInfo, uploadInfoAdmin)
