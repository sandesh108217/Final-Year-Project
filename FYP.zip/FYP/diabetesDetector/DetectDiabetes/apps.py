from django.apps import AppConfig


class DetectdiabetesConfig(AppConfig):
    name = 'DetectDiabetes'
