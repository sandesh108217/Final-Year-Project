from django.shortcuts import render, redirect
from django.utils import timezone
from django.contrib.auth.models import User, auth
from django.http import HttpResponse
from .models import uploadInfo


# Create your views here.

def index(request):
    return render(request, 'index.html')


def uploadInfo(request):
    information = uploadInfo.objects.all()
    return render(request, 'info.html', {'information': information})



