from django.db import models


# Create your models here.


class uploadInfo(models.Model):
    title = models.CharField(max_length=255)
    info = models.CharField(max_length=8000)
    date = models.DateTimeField(auto_now=True)





