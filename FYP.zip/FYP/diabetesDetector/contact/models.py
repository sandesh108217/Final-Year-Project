from django.db import models


# Create your models here.


class contactUs(models.Model):
    Name = models.CharField(max_length=50)
    Email = models.CharField(max_length=70)
    Subject = models.CharField(max_length=100)
    Message = models.CharField(max_length=1000)
    date = models.DateTimeField(auto_now=True)


    



