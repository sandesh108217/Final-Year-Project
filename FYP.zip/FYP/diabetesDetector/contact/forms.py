from django import forms
from django.forms import ModelForm
from .models import contactUs


class Contactforms(forms.ModelForm):
    class Meta:
        model = contactUs
        fields = ['Name', 'Email', 'Subject', 'Message']
