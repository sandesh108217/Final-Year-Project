from django.shortcuts import render, redirect
from .forms import Contactforms
from django.contrib import messages


# Create your views here.


def contact(request):
    if request.method == 'POST':
        form = Contactforms(request.POST or None)
        form.save()
        messages.info(request, 'Form submitted successfully')
        return redirect('/')

    else:
        return render(request, 'index.html')
