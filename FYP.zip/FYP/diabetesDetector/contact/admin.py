from django.contrib import admin
from .models import contactUs


# Register your models here.
class contactUsAdmin(admin.ModelAdmin):
    list_display = ('Name', 'Email', 'Subject', 'Message', 'date')


admin.site.register(contactUs, contactUsAdmin)
